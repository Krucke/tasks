<?php

class Controller {

    public $model;
    public $view;
    public $pagination;

    function __construct()
    {
        $this->view = new View();
    }

    function action_index()
    {

    }

    function goHome(){
        header('Location: http://mysite.local');
    }

    function guest(){
        echo "<script>alert('Ваше сообщение отправлено!'); location.href='http://mysite.local';</script>";
    }

    function success(){
        echo "<script>alert('Задача успешно добавлена!'); location.href='http://mysite.local';</script>";
    }

    function err(){
        echo "<script>alert('Произошла ошибка при добавлении записи!'); location.href='http://mysite.local';</script>";
    }
}
?>