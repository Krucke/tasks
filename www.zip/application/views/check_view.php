<?php
echo $data;